package com.walmart.cloudItem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudItemAttributeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudItemAttributeApplication.class, args);
	}
}
